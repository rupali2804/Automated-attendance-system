function varargout = RecogFace(varargin)
% RECOGFACE MATLAB code for RecogFace.fig
%      RECOGFACE, by itself, creates a new RECOGFACE or raises the existing
%      singleton*.
%
%      H = RECOGFACE returns the handle to a new RECOGFACE or the handle to
%      the existing singleton*.
%
%      RECOGFACE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in RECOGFACE.M with the given input arguments.
%
%      RECOGFACE('Property','Value',...) creates a new RECOGFACE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before RecogFace_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to RecogFace_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help RecogFace

% Last Modified by GUIDE v2.5 21-Apr-2016 12:03:39

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @RecogFace_OpeningFcn, ...
                   'gui_OutputFcn',  @RecogFace_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before RecogFace is made visible.
function RecogFace_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to RecogFace (see VARARGIN)
warning('off', 'imaq:peekdata:tooManyFramesRequested');
imaqreset;
% Choose default command line output for RecogFace
handles.output = hObject;
s='FACE'
save('nm');
save('nm','s');
k=0;
save('no');
save('no','k');
set(handles.axes1, 'XtickLabel',[], 'YtickLabel',[]);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes RecogFace wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = RecogFace_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 handles.vid = webcam;
    handles.vid.TimerPeriod =0.04;%0.04
   handles.vid.TimerFcn = {@videoTimerFunction, handles};
   
   % start acquisition
   start(handles.vid);
    % Update handles structure
   guidata(hObject, handles);
   
   
   
   % Timer Function
function videoTimerFunction(vid, eventdata, handles)
t1=load('no');
k=t1.k+1;
save('no','k');
t=load('nm');
s=t.s;
% get a single frame
IMG = peekdata(vid,1);

% FindFinger(IMG, handles.axes2, handles.axes3);

if isempty(IMG)
    return;
end

if ischar(IMG)
    IMG = imread(IMG);
end

imshow(IMG, 'Parent', handles.axes1);
FDetect = vision.CascadeObjectDetector('FrontalFaceCART');
face = step(FDetect,IMG);
if(face)
    
I_face=insertObjectAnnotation(IMG,'rectangle',face(1 , :),s);

imshow(I_face, 'Parent', handles.axes1)
I=imcrop(IMG,face(1 , :));
I=imresize(I,[100 100]);
I=rgb2gray(I);
m=mean(mean(I));
t=112-m;
I(:,:)=I(:,:)+t(:,:);
imwrite(I,'.\Test.jpg');

if(k/5~=0)
   datapath='.\DB';
TestImage='.\Test.jpg';

recog_img = facerecog(datapath,TestImage);

 s=fileread(strcat('.\infomation\',recog_img,'.txt')); 
 save('nm','s');
 imwrite(I,strcat('.\Atten\',s,'.jpg'));
end
end



% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

   stop(handles.vid);
   
   % delete video object
   delete(handles.vid);
  
   % clear image
   cla(handles.axes1);
