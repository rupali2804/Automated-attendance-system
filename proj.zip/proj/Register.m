function varargout = Register(varargin)
% REGISTER MATLAB code for Register.fig

% Last Modified by GUIDE v2.5 22-Apr-2016 12:35:01

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Register_OpeningFcn, ...
                   'gui_OutputFcn',  @Register_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Register is made visible.
function Register_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Register (see VARARGIN)

warning('off', 'imaq:peekdata:tooManyFramesRequested');
imaqreset;

D = dir('.\DB');
id = 0;
for i=1 : size(D,1)
    if not(strcmp(D(i).name,'.')|strcmp(D(i).name,'..')|strcmp(D(i).name,'Thumbs.db'))
        id = id + 1; % Number of all images in the training database
    end
end
save('dbin','id');

% clear image
set(handles.axes1, 'XtickLabel',[], 'YtickLabel',[]);
set(handles.axes2, 'XtickLabel',[], 'YtickLabel',[]);


% Choose default command line output for Register
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Register wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Register_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)

   % create video object
   handles.vid = webcam;
    handles.vid.TimerPeriod =0.04;%0.04
   handles.vid.TimerFcn = {@videoTimerFunction, handles};
   
   % start acquisition
   start(handles.vid);
    % Update handles structure
   guidata(hObject, handles);
   


   
  

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
 
   
   stop(handles.vid);
   
   % delete video object
   delete(handles.vid);
   
   % clear image
  % cla(handles.axes1);
     
   
   


% Timer Function
function videoTimerFunction(vid, eventdata, handles)

% get a single frame
IMG = peekdata(vid,1);
% FindFinger(IMG, handles.axes2, handles.axes3);

if isempty(IMG)
    return;
end

if ischar(IMG)
    IMG = imread(IMG);
end
imshow(IMG, 'Parent', handles.axes1);

FDetect = vision.CascadeObjectDetector('FrontalFaceCART');
face = step(FDetect,IMG);
if(face)
I_face = insertObjectAnnotation(IMG,'rectangle',face(1,:),'Face');

imshow(I_face, 'Parent', handles.axes1);
I = imcrop(IMG,face(1,:));
I = imresize(I,[100 100]);

end

imwrite(I,'.\Temp.jpg');




% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
I = imread('.\Temp.jpg');
imshow(I, 'Parent', handles.axes2);

t = load('dbin');
id = t.id + 1;
DBname = strcat('.\DB\',int2str(id),'.jpg');
save('dbin', 'id')
I=rgb2gray(I);
imwrite(I, DBname);
warndlg(strcat('Face : ',int2str(id),' Added'));




% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 close('Register');
 CheckD;
